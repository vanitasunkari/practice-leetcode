console.log("Hello Vanita");
const divEle = document.createElement("div");
divEle.innerText = "Hello Vanita";
document.body.append(divEle);
